# naoki-yoko-perso
Ce bot personnalisé permet de gerer: - modération - automodération - antiraid - administration - vocaux temporaire - logs - générateur d'embed - giveaway - ticket - Informations


Ancien bot perso naoki support développé par moi.
