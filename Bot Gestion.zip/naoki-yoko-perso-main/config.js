module.exports = {
    app: {
        px: 'ton prefix',
        token: 'ton token',
        owners: 'id bruyer',
        funny: 'id dev',
        color: 'couleur',
        footer: 'ton footer',
        maxserver: '6',
        maxVol: '150',
        everyoneMention: false,
        hostedBy: true,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
}